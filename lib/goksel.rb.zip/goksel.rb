require 'ruble'
 
with_defaults :scope => 'text.html,source.js,source.php source.php.embedded.block.html', :input => :none, :output => :insert_as_snippet do |bundle|
    snippet "con" do |s|
        s.trigger = "con"
        s.expansion = "console.log(${1:var});"
      end
end