require 'ruble'
    
bundle do |b|
  b.author = "Your Name"
  b.display_name = "My Tools"
end