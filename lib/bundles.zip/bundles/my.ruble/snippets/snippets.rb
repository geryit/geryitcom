require 'ruble'

with_defaults :scope => 'text.html,source.js,source.php source.php.embedded.block.html', :input => :none, :output => :insert_as_snippet do |bundle|
	command 'console.log()' do |cmd|
		cmd.key_binding = 'M1+M2+.'
		cmd.input = :selection
		cmd.invoke do |context|
		  selection = ENV['TM_SELECTED_TEXT'] || ''
		  if selection.length > 0
			"console.log(${1:#{selection}})"
		  else
			"console.log($0)"
		  end
		end
	end
end
